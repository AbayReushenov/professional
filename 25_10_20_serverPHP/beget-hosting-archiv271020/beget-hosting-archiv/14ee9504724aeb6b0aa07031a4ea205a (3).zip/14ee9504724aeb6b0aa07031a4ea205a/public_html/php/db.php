<?php
  $mysqli = mysqli_connect("localhost", "vladle43_edu0994", "Jp72ZFz%", "vladle43_edu0994");
?>
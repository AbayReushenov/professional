<?php
  echo $_SERVER['REQUEST_URI'];
?>
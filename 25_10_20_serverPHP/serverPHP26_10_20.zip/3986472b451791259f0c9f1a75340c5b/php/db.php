<?php
  $mysqli = new mysqli("localhost", "hostingaba_1", "345Wa110", "hostingaba_1");
?>
